package dml;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.RetriesExhaustedWithDetailsException;
import org.apache.hadoop.hbase.util.Bytes;

public class InsertDataFromFile {
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException {
		Configuration conf = HBaseConfiguration.create();
		
		System.out.println("Creating HTable instance to 'people'...");
		HTable table = new HTable(conf, "people");
		

		System.out.println("Setting AutoFlush to false...");
		table.setAutoFlush(false);
		
		ArrayList<Put> putList = new ArrayList<Put>();
		
		try {
			
			BufferedReader br = new BufferedReader(new FileReader("customer.dat"));
			String line;
	        while ((line = br.readLine()) != null) 
	        {
	        	Put put = new Put(Bytes.toBytes(line.split(",")[0]));
	    		put.add(Bytes.toBytes("detail"), Bytes.toBytes("name"), Bytes.toBytes(line.split(",")[1]));
	    		put.add(Bytes.toBytes("detail"), Bytes.toBytes("location"), Bytes.toBytes(line.split(",")[2]));
	    		put.add(Bytes.toBytes("detail"), Bytes.toBytes("age"), Bytes.toBytes(line.split(",")[3]));	 	
	    		putList.add(put1);
			}
				
			System.out.println("Adding put list to the table...");
			table.put(putList);
			
			System.out.println("Write Buffer before put: " + table.getWriteBuffer());
			System.out.println("Count of Write Buffer before put: " + table.getWriteBuffer().size());
			
			System.out.println("Flushing commits to the table...");
			table.flushCommits();
		}
		catch(RetriesExhaustedWithDetailsException e)
		{
			//Client check fails and hence no put operation is performed
			System.err.println("Number of exceptions: " + e.getNumExceptions());
			System.err.println("Exception Message: " + e.getMessage());
		}
		catch (Exception e) {
			System.err.println("Generic Exception: " + e.getMessage());
		}
		finally {
			//Nothing will be there in write buffer as we tried to do a list-based put and it failed the check at client side.
			System.out.println("Content of Write Buffer after catching exception: " + table.getWriteBuffer());
			System.out.println("Closing the table...");
			table.close();

		}
	}
}
